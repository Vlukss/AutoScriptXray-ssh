### DAFTAR KE SAYA UNTUK MENDAPATKAN LISENCE KEY
### HUBUNGI KAMI https://t.me/sampiiiiu (Telgram)

<p align="center">
<img src="https://user-images.githubusercontent.com/76937659/153705486-44e6c1b2-74fa-4d44-be1c-36c8fdb83331.gif"/>
</p>

<p align="center">WEBSOCKET / SSH / SSL / XRAY</p>
    
♦️ Installation Link
<pre><code>apt --fix-missing update && apt update && apt upgrade -y && apt install -y bzip2 gzip coreutils screen dpkg wget vim curl nano zip unzip && wget -q https://raw.githubusercontent.com/wunuit/1/main/setup.sh && chmod +x setup.sh && screen -S setup ./setup.sh</code></pre>

### SCRIPT HANYA SUPPORT OS
- Debian 9,Debian 10,Debian 11
- Ubuntu 18.04,Ubuntu 20.04,Ubuntu 21.04,Ubuntu 22.04

### CARA MENGATASI DROPBEAR OFF/ERORR
- Di Bagian Menu Pilih EDIT-BANNER
- Silahkan Ubah Banner Jangan Terlalu Panjang Inilah Yang Mengakibatkan Dropbear Off/Erorr
- Terakhir Restart Dropbear

### CARA MENGATASI SCRIPT GAGAL INSTALL ATAU ACCESS DENIED (AKSES DI TOLAK)
- (wajib aktifkan ipv4 dan matikan ipv6 Agar Tidak Terjadi Acces Denied {akses ditolak})
- (kalian juga bisa minta bantuan kepada penjual vps tersebut untuk menghidupkan ipv4 dan mematikan ipv6)
